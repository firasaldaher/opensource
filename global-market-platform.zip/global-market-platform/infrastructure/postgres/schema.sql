-- ============================================================
-- GLOBAL MARKET INTELLIGENCE PLATFORM — DATABASE SCHEMA
-- PostgreSQL 16
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- ─── ENUMS ──────────────────────────────────────────────────

CREATE TYPE user_role AS ENUM ('buyer', 'seller', 'admin', 'analyst');
CREATE TYPE listing_type AS ENUM ('physical', 'digital', 'service');
CREATE TYPE listing_status AS ENUM ('draft', 'active', 'paused', 'sold', 'deleted');
CREATE TYPE order_status AS ENUM ('pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded');
CREATE TYPE alert_severity AS ENUM ('low', 'medium', 'high', 'critical');
CREATE TYPE event_type AS ENUM ('political', 'economic', 'military', 'natural', 'social', 'technology');
CREATE TYPE currency_code AS ENUM ('USD', 'EUR', 'GBP', 'JPY', 'AED', 'SAR', 'EGP', 'LBP', 'TRY', 'CNY');

-- ============================================================
-- SECTION 1: USERS & AUTH
-- ============================================================

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email           VARCHAR(255) UNIQUE NOT NULL,
    username        VARCHAR(50) UNIQUE NOT NULL,
    password_hash   TEXT,
    full_name       VARCHAR(255),
    avatar_url      TEXT,
    role            user_role DEFAULT 'buyer',
    is_verified     BOOLEAN DEFAULT false,
    is_active       BOOLEAN DEFAULT true,
    preferred_currency currency_code DEFAULT 'USD',
    preferred_lang  VARCHAR(10) DEFAULT 'en',
    timezone        VARCHAR(50) DEFAULT 'UTC',
    last_login      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE oauth_accounts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    provider        VARCHAR(50) NOT NULL, -- google, github, linkedin
    provider_id     VARCHAR(255) NOT NULL,
    access_token    TEXT,
    refresh_token   TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(provider, provider_id)
);

CREATE TABLE user_sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    token           TEXT UNIQUE NOT NULL,
    ip_address      INET,
    user_agent      TEXT,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 2: SELLER PROFILES
-- ============================================================

CREATE TABLE seller_profiles (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    shop_name       VARCHAR(255) UNIQUE NOT NULL,
    shop_slug       VARCHAR(255) UNIQUE NOT NULL,
    bio             TEXT,
    logo_url        TEXT,
    banner_url      TEXT,
    country_code    CHAR(2),
    city            VARCHAR(100),
    stripe_account_id VARCHAR(255),
    is_verified     BOOLEAN DEFAULT false,
    total_sales     INTEGER DEFAULT 0,
    rating          DECIMAL(3,2) DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 3: MARKETPLACE
-- ============================================================

CREATE TABLE categories (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(100) NOT NULL,
    slug            VARCHAR(100) UNIQUE NOT NULL,
    parent_id       UUID REFERENCES categories(id),
    icon            VARCHAR(50),
    listing_type    listing_type,
    sort_order      INTEGER DEFAULT 0,
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE listings (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    seller_id       UUID REFERENCES seller_profiles(id) ON DELETE CASCADE,
    category_id     UUID REFERENCES categories(id),
    type            listing_type NOT NULL,
    title           VARCHAR(500) NOT NULL,
    slug            VARCHAR(500) UNIQUE NOT NULL,
    description     TEXT,
    short_desc      VARCHAR(500),
    price           DECIMAL(12,2) NOT NULL,
    currency        currency_code DEFAULT 'USD',
    compare_price   DECIMAL(12,2),
    stock           INTEGER,
    sku             VARCHAR(100),
    status          listing_status DEFAULT 'draft',
    tags            TEXT[],
    metadata        JSONB DEFAULT '{}',
    view_count      INTEGER DEFAULT 0,
    sale_count      INTEGER DEFAULT 0,
    rating          DECIMAL(3,2) DEFAULT 0,
    review_count    INTEGER DEFAULT 0,
    is_featured     BOOLEAN DEFAULT false,
    published_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE listing_images (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    listing_id      UUID REFERENCES listings(id) ON DELETE CASCADE,
    url             TEXT NOT NULL,
    alt_text        VARCHAR(255),
    is_primary      BOOLEAN DEFAULT false,
    sort_order      INTEGER DEFAULT 0
);

CREATE TABLE digital_files (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    listing_id      UUID REFERENCES listings(id) ON DELETE CASCADE,
    filename        VARCHAR(255) NOT NULL,
    file_url        TEXT NOT NULL,
    file_size       BIGINT,
    mime_type       VARCHAR(100),
    version         VARCHAR(50) DEFAULT '1.0',
    download_count  INTEGER DEFAULT 0
);

-- ============================================================
-- SECTION 4: ORDERS & PAYMENTS
-- ============================================================

CREATE TABLE orders (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    buyer_id        UUID REFERENCES users(id),
    status          order_status DEFAULT 'pending',
    total_amount    DECIMAL(12,2) NOT NULL,
    currency        currency_code DEFAULT 'USD',
    shipping_address JSONB,
    notes           TEXT,
    stripe_payment_intent VARCHAR(255),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE order_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id        UUID REFERENCES orders(id) ON DELETE CASCADE,
    listing_id      UUID REFERENCES listings(id),
    seller_id       UUID REFERENCES seller_profiles(id),
    quantity        INTEGER NOT NULL DEFAULT 1,
    unit_price      DECIMAL(12,2) NOT NULL,
    total_price     DECIMAL(12,2) NOT NULL,
    platform_fee    DECIMAL(12,2) DEFAULT 0,
    seller_amount   DECIMAL(12,2) NOT NULL
);

CREATE TABLE payouts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    seller_id       UUID REFERENCES seller_profiles(id),
    amount          DECIMAL(12,2) NOT NULL,
    currency        currency_code DEFAULT 'USD',
    stripe_transfer_id VARCHAR(255),
    status          VARCHAR(50) DEFAULT 'pending',
    paid_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 5: REVIEWS & MESSAGES
-- ============================================================

CREATE TABLE reviews (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    listing_id      UUID REFERENCES listings(id) ON DELETE CASCADE,
    reviewer_id     UUID REFERENCES users(id),
    order_id        UUID REFERENCES orders(id),
    rating          INTEGER CHECK (rating >= 1 AND rating <= 5),
    title           VARCHAR(255),
    body            TEXT,
    is_verified     BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE messages (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id       UUID REFERENCES users(id),
    receiver_id     UUID REFERENCES users(id),
    listing_id      UUID REFERENCES listings(id),
    subject         VARCHAR(255),
    body            TEXT NOT NULL,
    is_read         BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE wishlists (
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    listing_id      UUID REFERENCES listings(id) ON DELETE CASCADE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, listing_id)
);

-- ============================================================
-- SECTION 6: WORLD MONITOR
-- ============================================================

CREATE TABLE news_sources (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(255) NOT NULL,
    url             TEXT NOT NULL,
    rss_url         TEXT,
    country_code    CHAR(2),
    language        VARCHAR(10),
    category        VARCHAR(100),
    reliability_score DECIMAL(3,2) DEFAULT 0.5,
    is_active       BOOLEAN DEFAULT true,
    last_crawled    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE news_articles (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_id       UUID REFERENCES news_sources(id),
    title           TEXT NOT NULL,
    content         TEXT,
    summary         TEXT,
    url             TEXT UNIQUE NOT NULL,
    published_at    TIMESTAMPTZ,
    author          VARCHAR(255),
    country_code    CHAR(2),
    language        VARCHAR(10),
    event_type      event_type,
    sentiment_score DECIMAL(4,3), -- -1 to 1
    importance_score DECIMAL(4,3) DEFAULT 0,
    keywords        TEXT[],
    entities        JSONB DEFAULT '{}',
    lat             DECIMAL(10,7),
    lng             DECIMAL(10,7),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE countries (
    code            CHAR(2) PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100),
    region          VARCHAR(100),
    capital         VARCHAR(100),
    population      BIGINT,
    gdp             DECIMAL(20,2),
    currency        VARCHAR(10),
    flag_url        TEXT,
    instability_index DECIMAL(4,2) DEFAULT 0, -- 0-100
    risk_level      alert_severity DEFAULT 'low',
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE geopolitical_events (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title           VARCHAR(500) NOT NULL,
    description     TEXT,
    event_type      event_type NOT NULL,
    severity        alert_severity DEFAULT 'low',
    country_codes   CHAR(2)[],
    lat             DECIMAL(10,7),
    lng             DECIMAL(10,7),
    started_at      TIMESTAMPTZ,
    ended_at        TIMESTAMPTZ,
    economic_impact DECIMAL(5,2), -- -100 to 100
    sources         TEXT[],
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE keyword_alerts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    keyword         VARCHAR(255) NOT NULL,
    country_codes   CHAR(2)[],
    severity_filter alert_severity,
    notify_email    BOOLEAN DEFAULT true,
    notify_push     BOOLEAN DEFAULT true,
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 7: ECONOMIC ANALYTICS
-- ============================================================

CREATE TABLE stock_exchanges (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code            VARCHAR(20) UNIQUE NOT NULL,
    name            VARCHAR(255) NOT NULL,
    country_code    CHAR(2),
    timezone        VARCHAR(50),
    open_time       TIME,
    close_time      TIME,
    currency        VARCHAR(10),
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE market_indices (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    exchange_id     UUID REFERENCES stock_exchanges(id),
    symbol          VARCHAR(50) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    current_value   DECIMAL(15,4),
    change_pct      DECIMAL(8,4),
    volume          BIGINT,
    market_cap      DECIMAL(25,2),
    last_updated    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE market_snapshots (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    index_id        UUID REFERENCES market_indices(id),
    value           DECIMAL(15,4) NOT NULL,
    change_pct      DECIMAL(8,4),
    volume          BIGINT,
    recorded_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE economic_indicators (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    country_code    CHAR(2) REFERENCES countries(code),
    indicator_name  VARCHAR(255) NOT NULL, -- GDP, CPI, Unemployment
    value           DECIMAL(15,4),
    unit            VARCHAR(50),
    period          VARCHAR(20), -- 2024-Q1, 2024-01
    source          VARCHAR(255),
    recorded_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE ai_reports (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title           VARCHAR(500) NOT NULL,
    content         TEXT NOT NULL,
    report_type     VARCHAR(100), -- market, geopolitical, investment
    country_codes   CHAR(2)[],
    model_used      VARCHAR(100),
    generated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 8: NOTIFICATIONS
-- ============================================================

CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    title           VARCHAR(255) NOT NULL,
    body            TEXT,
    type            VARCHAR(100),
    data            JSONB DEFAULT '{}',
    is_read         BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX idx_listings_seller ON listings(seller_id);
CREATE INDEX idx_listings_category ON listings(category_id);
CREATE INDEX idx_listings_status ON listings(status);
CREATE INDEX idx_listings_type ON listings(type);
CREATE INDEX idx_listings_tags ON listings USING GIN(tags);
CREATE INDEX idx_listings_title_search ON listings USING GIN(to_tsvector('english', title));

CREATE INDEX idx_news_articles_source ON news_articles(source_id);
CREATE INDEX idx_news_articles_country ON news_articles(country_code);
CREATE INDEX idx_news_articles_published ON news_articles(published_at DESC);
CREATE INDEX idx_news_articles_keywords ON news_articles USING GIN(keywords);
CREATE INDEX idx_news_articles_title_search ON news_articles USING GIN(to_tsvector('english', title));

CREATE INDEX idx_orders_buyer ON orders(buyer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_market_snapshots_recorded ON market_snapshots(recorded_at DESC);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);

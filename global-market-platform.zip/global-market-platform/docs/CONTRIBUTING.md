# Contributing to Global Market Intelligence Platform

Thank you for your interest in contributing! 🎉

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOUR_USERNAME/global-market-platform.git`
3. Create a branch: `git checkout -b feature/your-feature-name`

## Development Setup

### Prerequisites
- Docker & Docker Compose
- Node.js 18+
- Python 3.11+

### Setup
```bash
cp .env.example .env
docker-compose up -d postgres redis meilisearch
cd frontend && npm install && npm run dev
cd backend && pip install -r requirements.txt && uvicorn main:app --reload
```

## Code Style

**Frontend:** ESLint + Prettier (run `npm run lint`)
**Backend:** Black + Ruff (run `black . && ruff check .`)

## Pull Request Process

1. Ensure tests pass
2. Update documentation if needed
3. Reference any related issues
4. Request review from maintainers

## Reporting Bugs

Use the GitHub Issues template and include:
- Steps to reproduce
- Expected vs actual behavior
- Screenshots if applicable

## License

By contributing, you agree your contributions will be licensed under the MIT License.

# 🌍 Global Market Intelligence Platform

> An open-source global marketplace with real-time economic monitoring, geopolitical analytics, and AI-powered insights.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Next.js](https://img.shields.io/badge/Next.js-14-black)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104-green)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16-blue)
![Docker](https://img.shields.io/badge/Docker-ready-blue)

---

## ✨ Features

### 🛒 Global Marketplace
- Physical products, digital goods & freelance services
- Multi-currency support (150+ currencies)
- Stripe Connect for global payouts
- Seller dashboard with analytics

### 📡 World Monitor
- 400+ global RSS news sources
- Real-time keyword alerts
- Country Instability Index (CII)
- Interactive 3D globe with event heatmap

### 📊 Economic Analytics
- 92 global stock exchanges (live data)
- Geopolitical risk scoring
- AI-generated market reports
- Investment opportunity radar

### 🤖 AI Engine
- Auto-summarize global news
- Predict market impact of events
- Personalized recommendations
- Pattern & correlation detection

---

## 🏗️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, TypeScript, Tailwind CSS |
| Backend | Python FastAPI |
| Database | PostgreSQL 16 + Redis |
| Real-time | WebSockets (Socket.io) |
| Maps | Mapbox GL + Three.js |
| AI | OpenAI API + Ollama (local) |
| Search | Meilisearch |
| Queue | Celery + Redis |
| Auth | NextAuth.js |
| Deploy | Docker + Nginx |

---

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 18+
- Python 3.11+
- PostgreSQL 16

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/global-market-platform.git
cd global-market-platform
```

### 2. Setup environment variables
```bash
cp .env.example .env
# Edit .env with your credentials
```

### 3. Start with Docker
```bash
docker-compose up -d
```

### 4. Run migrations
```bash
docker-compose exec backend alembic upgrade head
```

### 5. Open in browser
```
Frontend:   http://localhost:3000
Backend API: http://localhost:8000/docs
Meilisearch: http://localhost:7700
```

---

## 📁 Project Structure

```
global-market-platform/
├── frontend/               # Next.js 14 app
│   ├── src/
│   │   ├── app/           # App Router pages
│   │   ├── components/    # Reusable components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utilities & config
│   │   ├── store/         # Zustand state management
│   │   └── types/         # TypeScript types
│   └── public/            # Static assets
├── backend/               # FastAPI Python backend
│   ├── app/
│   │   ├── api/v1/        # API endpoints
│   │   ├── core/          # Config & security
│   │   ├── models/        # SQLAlchemy models
│   │   ├── schemas/       # Pydantic schemas
│   │   └── services/      # Business logic
│   └── migrations/        # Alembic migrations
├── services/              # Microservices
│   ├── rss-crawler/       # News aggregation
│   ├── price-tracker/     # Market data
│   ├── ai-engine/         # AI processing
│   └── notification/      # Push notifications
├── infrastructure/        # DevOps
│   ├── docker/
│   ├── nginx/
│   └── postgres/
└── docs/                  # Documentation
```

---

## 📅 Roadmap

- [x] Project architecture & setup
- [ ] Phase 1: Core authentication & user system
- [ ] Phase 2: World Monitor engine
- [ ] Phase 3: Global marketplace
- [ ] Phase 4: Economic analytics
- [ ] Phase 5: AI engine
- [ ] Phase 6: Mobile PWA

---

## 🤝 Contributing

We welcome contributions! Please read [CONTRIBUTING.md](docs/CONTRIBUTING.md) first.

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

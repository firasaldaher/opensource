from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    APP_NAME: str = "Global Market Intelligence Platform"
    APP_ENV: str = "development"
    SECRET_KEY: str
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000"]

    # Database
    DATABASE_URL: str
    REDIS_URL: str = "redis://localhost:6379"

    # Auth
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # Stripe
    STRIPE_SECRET_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""

    # AI
    OPENAI_API_KEY: str = ""
    OLLAMA_URL: str = "http://localhost:11434"

    # Search
    MEILISEARCH_URL: str = "http://localhost:7700"
    MEILISEARCH_KEY: str = ""

    # Market Data
    ALPHA_VANTAGE_KEY: str = ""
    FINNHUB_API_KEY: str = ""

    # Platform fee (%)
    PLATFORM_FEE_PERCENT: float = 5.0

    class Config:
        env_file = ".env"


settings = Settings()

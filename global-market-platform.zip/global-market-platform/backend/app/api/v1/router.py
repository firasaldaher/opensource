from fastapi import APIRouter

from app.api.v1.endpoints import (
    auth,
    users,
    listings,
    orders,
    monitor,
    analytics,
    search,
    admin,
)

api_router = APIRouter()

api_router.include_router(auth.router,      prefix="/auth",      tags=["Auth"])
api_router.include_router(users.router,     prefix="/users",     tags=["Users"])
api_router.include_router(listings.router,  prefix="/listings",  tags=["Marketplace"])
api_router.include_router(orders.router,    prefix="/orders",    tags=["Orders"])
api_router.include_router(monitor.router,   prefix="/monitor",   tags=["World Monitor"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["Analytics"])
api_router.include_router(search.router,    prefix="/search",    tags=["Search"])
api_router.include_router(admin.router,     prefix="/admin",     tags=["Admin"])

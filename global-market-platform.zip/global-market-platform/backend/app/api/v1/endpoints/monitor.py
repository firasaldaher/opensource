from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.schemas.monitor import NewsArticleOut, EventOut, CountryOut, AlertIn

router = APIRouter()


@router.get("/news", response_model=List[NewsArticleOut])
async def get_news(
    country: Optional[str] = None,
    event_type: Optional[str] = None,
    severity: Optional[str] = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
    db: Session = Depends(get_db)
):
    """Get global news articles with filters."""
    query = db.execute("""
        SELECT * FROM news_articles
        WHERE (:country IS NULL OR country_code = :country)
        AND (:event_type IS NULL OR event_type = :event_type)
        ORDER BY published_at DESC
        LIMIT :limit OFFSET :offset
    """, {"country": country, "event_type": event_type, "limit": limit, "offset": offset})
    return query.fetchall()


@router.get("/events", response_model=List[EventOut])
async def get_events(
    severity: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get geopolitical events for the map."""
    pass


@router.get("/countries", response_model=List[CountryOut])
async def get_countries(db: Session = Depends(get_db)):
    """Get all countries with instability index."""
    pass


@router.get("/countries/{code}")
async def get_country(code: str, db: Session = Depends(get_db)):
    """Get detailed country data with news and indicators."""
    pass


@router.post("/alerts")
async def create_alert(alert: AlertIn, db: Session = Depends(get_db)):
    """Create keyword alert for user."""
    pass


@router.get("/alerts")
async def get_user_alerts(db: Session = Depends(get_db)):
    """Get current user's keyword alerts."""
    pass
